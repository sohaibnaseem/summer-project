#!/bin/sh

BRIDGE0=br0
BRIDGE1=br2
GREIP=10.200.3.203

# Step 0: Remove all ports from bridges
for PORT in `/usr/bin/ovs-vsctl list-ports $BRIDGE1`
do
	/usr/bin/ovs-vsctl del-port $BRIDGE1 $PORT
done

for PORT in `/usr/bin/ovs-vsctl list-ports $BRIDGE0`
do
	/usr/bin/ovs-vsctl del-port $BRIDGE0 $PORT
done

# Step 1: Delete bridges
/usr/bin/ovs-vsctl del-br $BRIDGE0
/usr/bin/ovs-vsctl del-br $BRIDGE1

# Step 2: Show vSwitch config
/usr/bin/ovs-vsctl show 

