#!/bin/sh

BRIDGE0=br0
BRIDGE1=br2
GREIF=gre0
GREIP=10.200.3.203
TEPIF=tep0
TEPIP=192.168.200.22

# Step 0: Create internal bridges 
/usr/bin/ovs-vsctl add-br $BRIDGE0
/usr/bin/ovs-vsctl add-br $BRIDGE1

# Step 1: Assign TEP interface to BRIDGE0
/usr/bin/ovs-vsctl add-port $BRIDGE0 $TEPIF -- set interface $TEPIF type=internal
/sbin/ifconfig $TEPIF $TEPIP netmask 255.255.255.0

# Step 2: Set-up GRE tunnel with remote vSwitch 
/usr/bin/ovs-vsctl add-port $BRIDGE1 $GREIF -- set interface $GREIF type=gre options:remote_ip=$GREIP

# Step 3: Show vSwitch config
/usr/bin/ovs-vsctl show 
